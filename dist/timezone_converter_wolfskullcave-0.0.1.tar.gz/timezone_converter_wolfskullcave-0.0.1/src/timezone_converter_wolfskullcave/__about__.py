# SPDX-FileCopyrightText: 2025-present Kyle <67805222+wolfSkullCave@users.noreply.github.com>
#
# SPDX-License-Identifier: MIT
__version__ = "0.0.1"
